package models

type Filter struct {
	Field    string
	Operator string
	Values   []string
}
