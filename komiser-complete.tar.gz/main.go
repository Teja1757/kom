package main

import (
	"github.com/tailwarden/komiser/cmd"
)

func main() {
	cmd.Execute()
}
