package repository

import "errors"

var ErrQueryNotFound = errors.New("query not found")
