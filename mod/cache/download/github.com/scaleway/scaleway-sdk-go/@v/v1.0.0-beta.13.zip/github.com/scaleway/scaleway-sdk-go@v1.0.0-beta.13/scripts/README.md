# Scaleway GO SDK - Scripts

This directory contains useful scripts to work on scaleway-go-sdk.

### check_for_tokens.sh \*\*

Checks that no token are present in cassette file

```
Usage: ./script/check_for_tokens.sh
```

### release.sh \*\*

This script will trigger the release process.
For more information on the release process you can refer to ./release/release.js file

```
Usage: ./script/release.sh
```
