# Exec

This package provides an interface for `os/exec`. It makes it easier to mock
and replace in tests, especially with the [FakeExec](testing/fake_exec.go)
struct.
