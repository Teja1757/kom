# Support Policy

The support policy for all Mellium projects can be found in the main repo under
[`docs/SUPPORT.md`].

[`docs/SUPPORT.md`]: https://mellium.im/docs/SUPPORT
