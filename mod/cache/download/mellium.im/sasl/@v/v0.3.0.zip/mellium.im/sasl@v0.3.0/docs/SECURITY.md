# Security Policy

The security policy for all Mellium projects can be found in the main repo under
[`docs/SECURITY.md`].

[`docs/SECURITY.md`]: https://mellium.im/docs/SECURITY
